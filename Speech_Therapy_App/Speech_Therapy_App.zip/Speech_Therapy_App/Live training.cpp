#include "StdAfx.h"
//#include "Live training.h"

