		
        
        	// for (int i = 0; i < noOfWords; i++) {
			// 	std::string s1 = words[i];
			// 	this->listBox1->Items->Add(gcnew String( s1.c_str() ));
			// }


			// for (int i = 0; i < noOfWords; i++) {
			// 	std::string s1 = words[i];
			// 	this->listBox1->Items->Add(gcnew String( s1.c_str() ));
			// }




						// char pSheet[100];
			// char buf[100];

			//this->performance_label->Text = wordForPerformanceSheet;

			// sprintf(pSheet, "files/PastRecords/%s/performanceSheet.txt", wordForPerformanceSheet);

			// // FILE* fp = fopen("files/PastRecords/away/performanceSheet.txt", "r");
			// FILE* fp = fopen(pSheet, "r");
			// int x = 1;
			// float pb;
			// while (fgets(buf, 100, fp)) {
			// 	sscanf(buf, "%f", &pb);
			// 	chart1->Series[0]->Points->AddXY(x, pb);
			// 	x++;
			// }

			// fclose(fp);